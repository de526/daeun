package org.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.Dto.memDto;
import org.dao.Dao;

public class JoinAction implements Action{

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		memDto mdto = new memDto();
		mdto.setId(request.getParameter("id"));
		mdto.setPw(request.getParameter("pw"));
		mdto.setName(request.getParameter("name"));
		mdto.setTel(request.getParameter("tel"));
		
		//System.out.println(mdto.getId());
		
		Dao dao = Dao.getInstance();
		int result = dao.insertJoin(mdto);
		request.setAttribute("result", result);	
		
		
		return "jsp/join_result.jsp";
	}

}
