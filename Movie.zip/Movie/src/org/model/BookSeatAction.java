package org.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Dto.bookDto;
import org.Dto.memDto;
import org.dao.Dao;

public class BookSeatAction implements Action{

	@SuppressWarnings("null")
	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		
		String ddate = request.getParameter("ddate");
		String movie = request.getParameter("movie_name");
		String time = request.getParameter("time");
		String id = request.getParameter("id");

		Date dddate = Date.valueOf(ddate);
		
		HttpSession session = request.getSession();
//		memDto mdto = (memDto) session.getAttribute("mdto");		
//		String id = mdto.getId();
	
		
		bookDto bdto = new bookDto();
		bdto.setId(id);
		bdto.setDdate(dddate);
		bdto.setMovie(movie);
		bdto.setTime(time);
		
		List<String> seat_list= Dao.getInstance().Seat_check(bdto);
		
//		System.out.println(seat_list.get(0));
//		System.out.println(seat_list.get(1));

		List<Integer> seat = new ArrayList<Integer>();
		for(int i=0;i<seat_list.size();i++) {
			String[] list = seat_list.get(i).split(",");
			for(int j=0;j<list.length;j++) {
				seat.add(Integer.parseInt(list[j]));
			}
			
		}
		Collections.sort(seat);
		//숫자로 바꿔서 정렬
		
		session.setAttribute("bdto", bdto);
		request.setAttribute("seatArr", seat);
		
		
		return "jsp/seat.jsp";
		
	}

}
