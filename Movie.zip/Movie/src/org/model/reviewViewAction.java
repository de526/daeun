package org.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.Dto.reviewDto;
import org.dao.Dao;
import org.model.Action;

public class reviewViewAction implements Action {

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int idx = Integer.parseInt(request.getParameter("idx"));
		
		String curPage = request.getParameter("curPage");
		reviewDto rdto = Dao.getInstance().getReview(idx); 
		
		request.setAttribute("rdto", rdto);
		
		
		return "review/reviewView.jsp";
	}

}

