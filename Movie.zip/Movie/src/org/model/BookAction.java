package org.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Dto.memDto;

public class BookAction implements Action {

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception{
	
		//세션에 mdto 없으면 로그인창으로 이동 
		
		HttpSession session = request.getSession();
		memDto mdto = (memDto) session.getAttribute("mdto");
		
		if(mdto == null) {
			return "jsp/loginNeed.jsp";
		}		
		
		//mdto 있으면 가지고 book이동 
		
		
		
		
		return "jsp/book.jsp";
	}

}
