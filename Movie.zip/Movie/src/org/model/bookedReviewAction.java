package org.model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Dto.memDto;
import org.dao.Dao;

public class bookedReviewAction implements Action {

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String curPage = request.getParameter("curPage");
		request.setAttribute("curPgae", curPage);

		
		HttpSession session = request.getSession();
		memDto mdto = (memDto) session.getAttribute("mdto");
		if(mdto == null) {
			return "jsp/loginNeed.jsp";
		}
		List<String> bookedList = Dao.getInstance().getBookedMovie(mdto.getId());
	
		request.setAttribute("bookedList", bookedList);

		return "review/insertReview.jsp";
	}

}
