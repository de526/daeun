package org.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.Dto.reviewDto;
import org.controller.Paging;
import org.dao.Dao;

import org.model.Action;

public class reviewListAction implements Action {

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		Dao dao = Dao.getInstance();	

		//페이징처리.... 하기싫다
	
		int curPage = Integer.parseInt(request.getParameter("curPage"));
		if(curPage==0) {
			curPage = 1;			
		}
		
		
//		int curPage = 1;
//		if(curPages != null) {
//			curPage = Integer.parseInt(curPages);
//		}		

		request.setAttribute("curPage", curPage);

		int recordPerPage = 5;
		int begin = (curPage-1)*recordPerPage +1;
		int end = begin + recordPerPage -1;
		
		Map<String , Integer> map = new HashMap<String, Integer>();
		map.put("begin",begin);
		map.put("end",end);


		List<reviewDto> rlist = dao.getBoardList(map);
		
		request.setAttribute("rlist", rlist);
		

		int totalRecord = dao.getTotalRecord();

		
		String pagingView = Paging.getPaging("/Movie/reviewList.do", curPage, recordPerPage, totalRecord);

		request.setAttribute("pagingView", pagingView);
		
		return "review/reviewList.jsp";
	}

}
