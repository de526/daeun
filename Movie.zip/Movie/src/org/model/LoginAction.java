package org.model;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Dto.memDto;
import org.dao.Dao;

public class LoginAction implements Action {

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		Dao dao = Dao.getInstance();
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", id);
		map.put("pw",pw);
		
				
		memDto mdto = dao.logincheck(map);
		
		HttpSession session = request.getSession();
		session.setAttribute("mdto", mdto);
		
	
				
		return "jsp/login_result.jsp";
	}

}
