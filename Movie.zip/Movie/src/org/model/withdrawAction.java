package org.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Dto.memDto;
import org.dao.Dao;

public class withdrawAction implements Action {

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception{

		Dao dao = Dao.getInstance();
		HttpSession session = request.getSession();
		memDto mdto = (memDto) session.getAttribute("mdto");
		int result1 = dao.withdraw_book(mdto);
		int result2 = dao.withdraw_mem(mdto);
		if (result1 > 0 && result2 > 0) {
			session.removeAttribute("mdto");
		}
		return "jsp/withdraw_result.jsp";
	}

}
