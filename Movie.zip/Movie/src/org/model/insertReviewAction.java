package org.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Dto.memDto;
import org.Dto.reviewDto;
import org.dao.Dao;
import org.model.Action;

public class insertReviewAction implements Action {

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String title = request.getParameter("title");
		String movie_name = request.getParameter("movie_name");
		String star = request.getParameter("star");
		String curPage = request.getParameter("curPage");
		String content = request.getParameter("content");
	

		reviewDto rdto = new reviewDto();
		HttpSession session = request.getSession();
		memDto	mdto = (memDto) session.getAttribute("mdto");	
		rdto.setId(mdto.getId());
		rdto.setTitle(title);
		rdto.setMovie_name(movie_name);
		rdto.setStar(Integer.parseInt(star));
		rdto.setContent(content);

		int result = Dao.getInstance().insertReview(rdto);
		
		request.setAttribute("result",result);
	

		return "review/insertReview_result.jsp?curPage="+curPage;
	}

}
