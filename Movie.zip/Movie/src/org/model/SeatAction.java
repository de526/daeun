package org.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Dto.bookDto;
import org.Dto.memDto;
import org.dao.Dao;

public class SeatAction implements Action{

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
			
		String[] seats = request.getParameterValues("ck_btn");
		String seat = "";
		for(int i=0;i<seats.length;i++) {
			seat += seats[i]+",";
		}
		seat = seat.substring(0, seat.length()-1);
		
		//System.out.println(seat);
		HttpSession session = request.getSession();
		bookDto bdto = (bookDto) session.getAttribute("bdto");
		
		bdto.setSeat(seat);
		
		Dao dao = Dao.getInstance();
		int result = dao.insertBook(bdto);
		
		request.setAttribute("result", result);
		
		return "jsp/book_result.jsp";
	}
	

}
