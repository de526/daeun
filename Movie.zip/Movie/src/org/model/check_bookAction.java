package org.model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Dto.bookDto;
import org.Dto.memDto;
import org.dao.Dao;

public class check_bookAction implements Action{

	@Override
	public String command(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		HttpSession session = request.getSession();
		memDto mdto = (memDto) session.getAttribute("mdto");

	
		if(mdto == null) {
			return "jsp/loginNeed.jsp";
		}		
		
	
		//mdto 받아서 id로 book_t에 검색해서 예약목록 출력
		Dao dao = Dao.getInstance();
		List<bookDto> list = dao.selectBook(mdto);
		

		
		request.setAttribute("list",list);
				

		return "jsp/check_book.jsp";
	}

}
