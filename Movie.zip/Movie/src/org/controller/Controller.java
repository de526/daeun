package org.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.model.Action;
import org.model.BookAction;
import org.model.BookSeatAction;
import org.model.JoinAction;
import org.model.LoginAction;
import org.model.SeatAction;
import org.model.bookedReviewAction;
import org.model.check_bookAction;
import org.model.insertReviewAction;
import org.model.reviewListAction;
import org.model.reviewViewAction;
import org.model.withdrawAction;

@WebServlet("*.do")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Controller() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");

		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String cmd = requestURI.substring(contextPath.length());

		Action action = null;
		String path = "";
		try {
			switch (cmd) {

			case "/book.do":
				action = new BookAction();
				break;
			// 예약페이지로 이동 로그인 정보가지고
			case "/login.do":
				action = new LoginAction();
				break;
			// 로그인 정보 체크 select
			case "/join.do":
				action = new JoinAction();
				break;
			// 회원가입 insert
			case "/BookSeat.do":
				action = new BookSeatAction();
				break;
			// 영화 날짜 시간 가지고 seat페이지로 이동
			case "/seat.do":
				action = new SeatAction();
				break;
			// seat 받아서 book insert
			case "/check_book.do":
				action = new check_bookAction();
				break;
			// 예약목록 select
			case "/withdraw.do":
				action = new withdrawAction();
				break;
			// 회원탈퇴

				
				
			case "/reviewList.do":
				action = new reviewListAction();
				break;
			// 리뷰 리스트 가져와서 출력
			case "/reviewView.do":
				action = new reviewViewAction();
				break;
			//해당 리뷰 보기 
			case "/insertReview.do":
				action = new insertReviewAction();
				break;
			//리뷰 db에 넣기
			case "/bookedReview.do":
				action = new bookedReviewAction();
				break;
				//예매내역에 있는 영화만 보여주는 정보가지고 insert페이지로 /로그인
			}
	
			path = action.command(request, response);
			request.getRequestDispatcher(path).forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
