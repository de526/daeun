package org.dao;

import java.util.List;
import java.util.Map;

import org.Dto.bookDto;
import org.Dto.memDto;
import org.Dto.movieDto;
import org.Dto.reviewDto;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.config.DBService;



public class Dao {
private SqlSessionFactory factory = null;
	
	// singleton
	private Dao() {	
		factory = DBService.getFactory();			// dao의 생성은 factory의 생성
	}
	private static Dao dao = new Dao();
	public static Dao getInstance() {
		return dao;
	}	
	//회원가입
	public int insertJoin(memDto mdto) {
		SqlSession sqlSession = factory.openSession();		
		int result = sqlSession.insert("memberjoin", mdto );
		if(result>0) {
			sqlSession.commit();
		}
		sqlSession.close();
		return result;
	}
	//로그인체크
	public memDto logincheck(Map<String , String> map) {
		SqlSession sqlSession = factory.openSession();
		memDto mdto = sqlSession.selectOne("login_id",map);
		sqlSession.close();
		return mdto;
	}
	//예매하기
	public int insertBook(bookDto bdto) {
		SqlSession sqlSession = factory.openSession();
		int result = sqlSession.insert("insertbook",bdto);
		if(result>0) {
			sqlSession.commit();
		}
		sqlSession.close();
		return result;
	}
	
//	public List<bookDto> selectBook(String id) {
//		SqlSession sqlSession = factory.openSession();
//		List<bookDto> list = sqlSession.selectList("book_id",id);
//		return list;
//		
//	}
	//예매내역 가져오기
	public List<bookDto> selectBook(memDto mdto) {
		SqlSession sqlSession = factory.openSession();
		List<bookDto> list = sqlSession.selectList("book_id",mdto);
		sqlSession.close();
		return list;
		
	}
	//메인에 영화 리스트가져오기
	public List<movieDto> getMovie() {
		SqlSession sqlSession = factory.openSession();
		List<movieDto> list = sqlSession.selectList("movieList");
		sqlSession.close();
		return list;		
	}
	
	//회원탈퇴1 - 예매내역 삭제
	public int withdraw_book(memDto mdto) {
		SqlSession sqlSession = factory.openSession();
		int result = sqlSession.delete("withdraw_book",mdto);
		if(result>0) {
			sqlSession.commit();
		}
		sqlSession.close();
		return result;
	}
	//회원탈퇴 2 - mem_T에서 삭제
	public int withdraw_mem(memDto mdto) {
		SqlSession sqlSession = factory.openSession();
		int result = sqlSession.delete("withdraw_mem",mdto);
		if(result>0) {
			sqlSession.commit();
		}
		sqlSession.close();
		return result;
	}
	//해당 영화 좌석 조회
	public List<String> Seat_check(bookDto bdto) {
		SqlSession sqlSession = factory.openSession();
		List<String> seat_list = sqlSession.selectList("seat_check",bdto);
		sqlSession.close();
		return seat_list;
		
	}
	//리뷰 하나 가져오기
	public reviewDto getReview(int idx) {
		SqlSession sqlSession = factory.openSession();
		reviewDto rdto = sqlSession.selectOne("reviewOne",idx);
		sqlSession.close();
		return rdto;
	}
	//전체 게시글수 구하기
	public int getTotalRecord() {
		SqlSession sqlSession = factory.openSession();
		int result = sqlSession.selectOne("select_total_record");
		sqlSession.close();
		return result;
	}
	//리뷰 갯수대로 가져오기
	public List<reviewDto> getBoardList(Map<String, Integer> map){
		SqlSession sqlSession = factory.openSession();
		List<reviewDto> list = sqlSession.selectList("select_board_by_map", map);
		sqlSession.close();
		return list;
	}
	//예매내역에 있는 영화목록 가져오기
	public List<String> getBookedMovie(String id){
		SqlSession sqlSession = factory.openSession();
		List<String> bookedList = sqlSession.selectList("booked_id",id);
		sqlSession.close();
		return bookedList;
	}
	//리뷰 작성
	public int insertReview(reviewDto rdto) {
		SqlSession sqlSession = factory.openSession();
		int result = sqlSession.insert("insertReview",rdto);
		if(result>0) {
			sqlSession.commit();
		}
		sqlSession.close();
		return result;
	}
	
}
